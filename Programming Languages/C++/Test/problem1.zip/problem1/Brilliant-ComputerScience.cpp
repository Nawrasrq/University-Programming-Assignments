#include "../Headers/Brilliant-ComputerScience.h"

void Brilliant_ComputerScience::eat(){
    std::cout << "eating a power bar" << std::endl;
}

void Brilliant_ComputerScience::walk(){
    std::cout << "walking slow, I'm near my computer" << std::endl;
}

void Brilliant_ComputerScience::talk(){
    std::cout << "talking slow, cs meetings are long so I have time" << std::endl;
}

void Brilliant_ComputerScience::think(){
    std::cout << "thinking slow, taking my time so I don't make mistakes" << std::endl;
}