#include "../Headers/Paychology-Major.h"

void Paychology_Major::eat(){
    std::cout << "eating a crosssiant" << std::endl;
}

void Paychology_Major::walk(){
    std::cout << "walking medium speed, I have a meeting with a patient" << std::endl;
}

void Paychology_Major::talk(){
    std::cout << "talking medium speed, talking with my patient" << std::endl;
}

void Paychology_Major::think(){
    std::cout << "thinking medium speed, formulating my thoughts" << std::endl;
}