#include "../Headers/Paradisio-Beings.h"
#include "../Headers/Loser-Barista.h"
#include "../Headers/Brilliant-ComputerScience.h"
#include "../Headers/Paychology-Major.h"

void Paradisio_Beings::set_values(string name, int age, int weight){
    this->name = name;
    this->age = age;
    this->weight = weight;
}
