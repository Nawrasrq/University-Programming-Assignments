#include "../Headers/Loser-Barista.h"

void Loser_Barista::eat(){
    std::cout << "eating a sandwhich" << std::endl;
}

void Loser_Barista::walk(){
    std::cout << "walking fast, gotta serve orders" << std::endl;
}

void Loser_Barista::talk(){
    std::cout << "talking fast, gotta take orders" << std::endl;
}

void Loser_Barista::think(){
    std::cout << "thinking fast, gotta make the right orders" << std::endl;
}